from django.apps import AppConfig


class CitysConfig(AppConfig):
    name = 'citys'
