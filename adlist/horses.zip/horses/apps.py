from django.apps import AppConfig


class HorsesConfig(AppConfig):
    name = 'horses'
